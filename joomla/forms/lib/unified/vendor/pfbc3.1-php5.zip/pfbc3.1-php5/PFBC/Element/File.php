<?php
class Element_File extends Element {
	protected $_attributes = array("type" => "file");
}
