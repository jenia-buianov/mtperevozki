Installation
============

Packagist
~~~~~~~~~

This library is available through Packagist with the vendor and package
identifier of ``j4mie/idiorm``

Please see the `Packagist documentation`_ for further information.

Download
~~~~~~~~

You can clone the git repository, download idiorm.php or a release tag
and then drop the idiorm.php file in the vendors/3rd party/libs
directory of your project.

.. _Packagist documentation: http://packagist.org/